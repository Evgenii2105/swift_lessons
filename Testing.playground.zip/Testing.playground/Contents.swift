import UIKit

var str = "hello, playground";


var name1 = "Alex"

name1 = "Ivan"

name1


var name2 = "Oleg"

name2 = "Jorj"

print("Evgeny")

print(name1 + " " + name2)

var colorblue = "blue"


